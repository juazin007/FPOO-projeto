
public class Main {

	public static void main(String[] args) {
		
		Media objMedia = new Media();
		
		objMedia.listarAlunos();

	}

}
